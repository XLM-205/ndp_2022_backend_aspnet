﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DevFreela.Core.DTOs
{
    public class SkillDTO
    {
        public int Id { get; set; }
        public string Description { get; set; }
    }
}
